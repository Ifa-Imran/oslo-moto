globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/UFgTVa6vdqrBDwvSPQB1K/_buildManifest.js",
    "static/UFgTVa6vdqrBDwvSPQB1K/_ssgManifest.js",
    "static/UFgTVa6vdqrBDwvSPQB1K/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/1jexzsn2qdw84.js",
    "static/chunks/316-2ttyp0wgx.js",
    "static/chunks/2g05-lers809t.js",
    "static/chunks/06j3juy1u5a-6.js",
    "static/chunks/3nc6x0_y5iwnk.js",
    "static/chunks/turbopack-1iok5h80r3gu-.js"
  ]
};
