module.exports=[633507,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_income_page_actions_13l_5xa.js.map