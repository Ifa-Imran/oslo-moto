module.exports=[335421,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_stake_page_actions_20bj9vv.js.map